"""Temporal referent integrity experiments."""

