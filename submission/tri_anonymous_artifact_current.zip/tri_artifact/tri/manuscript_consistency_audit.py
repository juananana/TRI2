"""Static consistency checks for the submission manuscript."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT_REPOSITORY = ROOT.parents[1]
if (DEVELOPMENT_REPOSITORY / "paper/AnonymousSubmission2027.tex").is_file():
    REPOSITORY = DEVELOPMENT_REPOSITORY
else:
    REPOSITORY = ROOT
PAPER = REPOSITORY / "paper/AnonymousSubmission2027.tex"
SUPPLEMENT = REPOSITORY / "paper/supplementary_material.tex"
BIB = REPOSITORY / "paper/aaai2027.bib"


FIRST_USE_EXPANSIONS = {
    "TRI": "temporal referent integrity",
    "LLM": "large language model",
    "CTA": "Compile-then-act",
    "ID": "entity identifier",
    "APIs": "application programming interfaces",
    "NLI": "natural-language inference",
    "PairAcc": "pair accuracy",
    "E2E": "end-to-end",
    "ITT": "intention-to-treat",
}


def _without_comments(text: str) -> str:
    return "\n".join(re.split(r"(?<!\\)%", line, maxsplit=1)[0] for line in text.splitlines())


def _citation_keys(text: str) -> set[str]:
    keys: set[str] = set()
    for match in re.finditer(r"\\cite\w*\{([^}]+)\}", text):
        keys.update(key.strip() for key in match.group(1).split(","))
    return keys


def _labels(text: str, command: str) -> set[str]:
    return set(re.findall(rf"\\{command}\{{([^}}]+)\}}", text))


def _plain_text(text: str) -> str:
    """Normalize simple LaTeX prose for robust first-use checks."""
    for _ in range(3):
        text = re.sub(r"\\[A-Za-z]+\*?(?:\[[^\]]*\])?\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\[A-Za-z]+", " ", text)
    return re.sub(r"\s+", " ", text.replace("{", " ").replace("}", " "))


def build_report(paper: Path = PAPER, bib: Path = BIB) -> dict[str, Any]:
    paper_text = _without_comments(paper.read_text(encoding="utf-8"))
    supplement_text = _without_comments(SUPPLEMENT.read_text(encoding="utf-8"))
    normalized_paper = re.sub(r"\s+", " ", paper_text)
    normalized_supplement = re.sub(r"\s+", " ", supplement_text)
    bib_text = _without_comments(bib.read_text(encoding="utf-8"))
    body = paper_text.split("\\begin{document}", 1)[-1]
    plain_body = _plain_text(body)
    checks: dict[str, bool] = {}

    first_use: dict[str, dict[str, int]] = {}
    for acronym, expansion in FIRST_USE_EXPANSIONS.items():
        match = re.search(rf"(?<![A-Za-z]){re.escape(acronym)}(?![A-Za-z])", plain_body)
        first = match.start() if match else -1
        defined = plain_body.find(expansion)
        first_use[acronym] = {"first": first, "definition": defined}
        checks[f"{acronym}_expanded_at_first_use"] = first < 0 or (defined >= 0 and defined <= first)

    cited = _citation_keys(paper_text)
    bib_keys = set(re.findall(r"@\w+\{([^,]+),", bib_text))
    references = _labels(paper_text, "ref")
    labels = _labels(paper_text, "label")
    checks["all_citations_have_bibliography_entries"] = cited <= bib_keys
    checks["all_cross_references_have_labels"] = references <= labels
    checks["no_legacy_table_abbreviations"] = not any(
        token in paper_text for token in ("Model / ctl.", " / Gen. &", "CTA/Gated")
    )
    checks["abstract_retains_scope_boundary"] = all(
        phrase in normalized_paper
        for phrase in (
            "a diagnostic built from matched Preserve/Reevaluate pairs",
            "Across three model backends on 240 authored cross-schema tasks, an author-designed Generic controller",
            "Source-derived effects were model-dependent",
            "a controlled diagnostic for selective re-resolution",
            "native prevalence and open-language generalization remain unresolved",
        )
    )
    checks["abstract_chronology_is_explicit"] = all(
        phrase in normalized_paper
        for phrase in (
            "Across three model backends on 240 authored cross-schema tasks",
            "A model-facing SQLite test",
            "With equal calls and identical base actor inputs, exposing a composite decision block",
        )
    )
    checks["body_chronology_is_explicit"] = all(
        phrase in normalized_paper
        for phrase in (
            "The Qwen package comparison is primary/frozen, with a later GLM replication",
            "Cross-schema attribution, matched-call contrasts, construct studies, and external audits are post-primary",
            "Rule* is post-hoc",
        )
    )
    checks["primary_is_explicitly_package_level"] = all(
        phrase in normalized_paper
        for phrase in (
            "The primary comparison is package-level and call-asymmetric",
            "from 103/160 for Generic to 157/160 for Lifecycle-Gated",
            "The full-diagnostic matched-call test compares History-only and Decision-visible actors with equal calls",
            "the contrast estimates the complete block rather than an individual field",
        )
    )
    checks["theory_certification_scope_is_explicit"] = all(
        phrase in paper_text
        for phrase in (
            "e_0&=q_r(S_0)\\in E",
            "A_P=N^{-1}\\sum_iY_{Pi}",
            "A_R=N^{-1}\\sum_iY_{Ri}",
            "use the same $N$ complete",
            "A=1-n/N",
            "worst-case",
            "\\Pr(O,B,U,X)",
        )
    ) and all(
        phrase in supplement_text
        for phrase in (
            "Proposition 1 (support-based observational equivalence)",
            "Proposition 2 (sharp aggregate certification bound)",
            "Proposition 3 (strict TRI-write pathway factorization)",
            "No independence assumption is used",
            "zero aggregate-to-PairAcc selection regret",
        )
    )
    checks["binding_drift_boundary_and_citation_are_explicit"] = all(
        phrase in normalized_paper
        for phrase in (
            "Binding Drift then tests whether an already committed primary referent persists",
            "TRI conditions on a correct initial binding and varies whether commitment occurs before or after the same transition",
            "In an author adaptation, entity lock favors Preserve, while self-reverification favors Reevaluate",
            "\\cite{babu2026bindingdrift}",
        )
    )
    checks["selector_visibility_boundary_is_explicit"] = all(
        phrase in normalized_paper
        for phrase in (
            "Controllers receive the instruction's natural-language selector",
            "Gold targets, normalized selector fields, and pre- and post-refresh winner IDs are withheld",
        )
    )
    checks["code_data_supplement_routing_is_explicit"] = all(
        phrase in normalized_paper
        for phrase in (
            "All prompts and interfaces are also in the anonymous Code and Data Supplement",
            "The anonymous artifact contains frozen inventories, prompts, raw outputs, reports, hashes, and the error taxonomy",
        )
    ) and all(
        phrase in normalized_supplement
        for phrase in (
            "Verbatim Matched-Call Interface",
            "Decision-visible adds one field",
            "IDs are never fuzzy-matched or repaired",
        )
    )
    checks["claim_evidence_map_and_result_status_are_explicit"] = (
        "Post-primary audits from frozen \\PrimaryDiagnostic{} and \\NewSchemaReplication{} outputs"
        in normalized_supplement
        and all(
            phrase in normalized_paper
            for phrase in (
                "Claim-to-evidence map",
                "Exact-target three-policy class; no internal-mechanism identification",
                "Cross-schema outcomes after correct initial binding",
                "Complete outcomes from the secondary/frozen 40-task model-facing SQLite test",
                "The Qwen package comparison is primary/frozen",
                "Cross-schema attribution, matched-call contrasts, construct studies, and external audits are post-primary",
                "Rule* is post-hoc",
            )
        )
    )
    checks["no_overstated_tie_or_sample_sufficiency_language"] = not any(
        phrase in paper_text + "\n" + supplement_text
        for phrase in (
            "CTA ties",
            "Qwen's tie",
            "sample-sufficiency",
            "not sample-limited",
        )
    )
    checks["external_extension_has_four_paper_facing_conditions"] = (
        "four-condition, 96-task extension" in normalized_paper
        and "five-condition, 96-task extension" not in paper_text.lower()
    )
    checks["source_anchored_transfer_retains_boundary"] = all(
        phrase in normalized_paper
        for phrase in (
            "instantiate the diagnostic over source-derived states and schemas",
            "not native tasks or prevalence evidence",
            "no method consistently improves execution accuracy",
        )
    )
    checks["conclusion_retains_scope_boundary"] = all(
        phrase in normalized_paper
        for phrase in (
            "Evidence is limited to single-refresh scalar workflows",
        )
    )
    return {
        "status": "zero-API static manuscript audit",
        "paper": str(paper.relative_to(REPOSITORY)),
        "bibliography": str(bib.relative_to(REPOSITORY)),
        "checks": checks,
        "first_use": first_use,
        "missing_bibliography_entries": sorted(cited - bib_keys),
        "missing_labels": sorted(references - labels),
    }


def validate(report: dict[str, Any]) -> None:
    failed = [name for name, passed in report["checks"].items() if not passed]
    if failed:
        raise ValueError(f"manuscript consistency audit failed: {', '.join(failed)}")


def markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Manuscript Consistency Audit",
        "",
        f"Status: {report['status']}.",
        "",
        "| Check | Result |",
        "|---|---:|",
    ]
    lines.extend(
        f"| `{name}` | {'PASS' if passed else 'FAIL'} |"
        for name, passed in report["checks"].items()
    )
    lines.extend(
        [
            "",
            f"Missing bibliography entries: {json.dumps(report['missing_bibliography_entries'])}",
            f"Missing labels: {json.dumps(report['missing_labels'])}",
            "",
        ]
    )
    return "\n".join(lines)
